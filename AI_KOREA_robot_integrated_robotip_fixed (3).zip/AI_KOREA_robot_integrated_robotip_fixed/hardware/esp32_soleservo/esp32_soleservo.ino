#include <WiFi.h>
#include <WebServer.h>
#include <HTTPClient.h>
#include <ESP32Servo.h>

// =========================
// ESP32 #1
// Servo 4 + Solenoid 1 + DC motor 1 (BTS7960)
// =========================
const char* SSID = "QWER";
const char* PASS = "sw02190219!!";

// ===== Recording Toggle Button =====
const char* FLASK = "http://10.31.202.162:5000";
const char* KEY = "NSAK_BUTTON_2026";
const int RECORD_BTN = 13;
int lastRecordState = HIGH;
unsigned long lastRecordDebounce = 0;
const unsigned long RECORD_DEBOUNCE_MS = 180;

void sendRecordToggle(){
  if(WiFi.status()!=WL_CONNECTED) return;
  HTTPClient http;
  http.begin(String(FLASK)+"/api/ui/record");
  http.addHeader("Content-Type","application/json");
  String body = String("{\"key\":\"")+KEY+"\",\"state\":\"pressed\"}";
  int code = http.POST(body);
  Serial.printf("BUTTON pressed -> Flask HTTP %d\n", code);
  http.end();
}

WebServer server(80);

// Servo pins
Servo servo1, servo2, servo3, servo4;
const int SERVO_PINS[4] = {18, 19, 21, 22};

// Solenoid relay
const int RELAY_PIN = 23;
const bool RELAY_ACTIVE_LOW = true;

// BTS7960
const int BTS_RPWM = 25;
const int BTS_LPWM = 26;
const int BTS_REN  = 27;
const int BTS_LEN  = 32;

void sendJson(int code, bool ok, const String& message) {
  String body = String("{\"ok\":") + (ok ? "true" : "false") +
                ",\"message\":\"" + message + "\"}";
  server.send(code, "application/json", body);
}

String body() { return server.arg("plain"); }

int jsonInt(const String& b, const String& key, int fallback) {
  int p = b.indexOf("\"" + key + "\"");
  if (p < 0) return fallback;
  p = b.indexOf(':', p);
  if (p < 0) return fallback;
  return b.substring(p + 1).toInt();
}

String jsonString(const String& b, const String& key, const String& fallback) {
  int p = b.indexOf("\"" + key + "\"");
  if (p < 0) return fallback;
  p = b.indexOf(':', p);
  if (p < 0) return fallback;
  p = b.indexOf('"', p + 1);
  if (p < 0) return fallback;
  int e = b.indexOf('"', p + 1);
  if (e < 0) return fallback;
  return b.substring(p + 1, e);
}

void relayOff() { digitalWrite(RELAY_PIN, RELAY_ACTIVE_LOW ? HIGH : LOW); }
void relayOn()  { digitalWrite(RELAY_PIN, RELAY_ACTIVE_LOW ? LOW : HIGH); }

void dcStop() {
  analogWrite(BTS_RPWM, 0);
  analogWrite(BTS_LPWM, 0);
}

void dcForward(int speed) {
  speed = constrain(speed, 0, 255);
  analogWrite(BTS_LPWM, 0);
  analogWrite(BTS_RPWM, speed);
}

void dcReverse(int speed) {
  speed = constrain(speed, 0, 255);
  analogWrite(BTS_RPWM, 0);
  analogWrite(BTS_LPWM, speed);
}

void dispense() {
  int slot = jsonInt(body(), "slot", 0);
  if (slot < 1 || slot > 4) {
    sendJson(400, false, "slot 1~4 only");
    return;
  }

  Servo* servos[4] = {&servo1, &servo2, &servo3, &servo4};
  Servo* s = servos[slot - 1];
  // 사탕 배출: 90도로 이동한 뒤 기준 위치(0도)로 복귀
  s->write(90);
  delay(500);
  s->write(0);

  sendJson(200, true, "servo dispense complete");
}


void dispensePair() {
  String b = body();
  int slotA = jsonInt(b, "slot_a", 0);
  int slotB = jsonInt(b, "slot_b", 0);
  bool solenoidA = jsonString(b, "action_a", "servo") == "solenoid";
  bool solenoidB = jsonString(b, "action_b", "servo") == "solenoid";

  if ((!solenoidA && (slotA < 1 || slotA > 4)) || (!solenoidB && (slotB < 1 || slotB > 4))) {
    sendJson(400, false, "slot_a/slot_b must be 1~4 for servo actions");
    return;
  }

  Servo* servos[4] = {&servo1, &servo2, &servo3, &servo4};

  // 두 배출 장치를 같은 loop에서 즉시 시작합니다.
  // 서보는 90도 이동, 솔레노이드는 동시에 ON.
  if (solenoidA || solenoidB) relayOn();
  if (!solenoidA) servos[slotA - 1]->write(90);
  if (!solenoidB) servos[slotB - 1]->write(90);
  delay(600);
  if (!solenoidA) servos[slotA - 1]->write(0);
  if (!solenoidB) servos[slotB - 1]->write(0);
  if (solenoidA || solenoidB) relayOff();

  sendJson(200, true, "pair dispense complete");
}

void solenoid() {
  int ms = constrain(jsonInt(body(), "duration", 1000), 50, 5000);
  relayOn();
  delay(ms);
  relayOff();
  sendJson(200, true, "solenoid complete");
}

void dcMotor() {
  String b = body();
  String command = jsonString(b, "command", "stop");
  int speed = constrain(jsonInt(b, "speed", 180), 0, 255);

  if (command == "forward") dcForward(speed);
  else if (command == "reverse") dcReverse(speed);
  else if (command == "stop") dcStop();
  else {
    sendJson(400, false, "forward/reverse/stop only");
    return;
  }

  sendJson(200, true, command);
}

void status() {
  sendJson(200, true, "ESP32 #1 ready");
}

void setup() {
  Serial.begin(115200);

  servo1.setPeriodHertz(50); servo2.setPeriodHertz(50);
  servo3.setPeriodHertz(50); servo4.setPeriodHertz(50);
  servo1.attach(SERVO_PINS[0]); servo2.attach(SERVO_PINS[1]);
  servo3.attach(SERVO_PINS[2]); servo4.attach(SERVO_PINS[3]);
  servo1.write(0); servo2.write(0); servo3.write(0); servo4.write(0);

  pinMode(RELAY_PIN, OUTPUT);
  relayOff();

  pinMode(BTS_REN, OUTPUT);
  pinMode(BTS_LEN, OUTPUT);
  digitalWrite(BTS_REN, HIGH);
  digitalWrite(BTS_LEN, HIGH);
  pinMode(BTS_RPWM, OUTPUT);
  pinMode(BTS_LPWM, OUTPUT);
  dcStop();

  WiFi.mode(WIFI_STA);
  pinMode(RECORD_BTN, INPUT_PULLUP);
  WiFi.begin(SSID, PASS);
  Serial.print("WiFi");
  while (WiFi.status() != WL_CONNECTED) { delay(300); Serial.print('.'); }
  Serial.println();
  Serial.print("ACTUATOR IP: "); Serial.println(WiFi.localIP());

  server.on("/dispense", HTTP_POST, dispense);
  server.on("/dispense_pair", HTTP_POST, dispensePair);
  server.on("/solenoid", HTTP_POST, solenoid);
  server.on("/dc", HTTP_POST, dcMotor);
  server.on("/status", HTTP_GET, status);
  server.begin();
  Serial.println("ESP32 #1 HTTP SERVER READY");
}

void loop() { server.handleClient();

  // Recording button (toggle)
  int reading = digitalRead(RECORD_BTN);
  if(reading != lastRecordState && millis()-lastRecordDebounce > RECORD_DEBOUNCE_MS){
      lastRecordDebounce = millis();
      lastRecordState = reading;
      if(reading == LOW){
          sendRecordToggle();
      }
  }
 }

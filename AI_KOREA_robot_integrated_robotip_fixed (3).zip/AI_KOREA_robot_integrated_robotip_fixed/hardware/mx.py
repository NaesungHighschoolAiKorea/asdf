from pymycobot import MyCobot280Socket
# Port 9000 is used by default
mc = MyCobot280Socket("10.31.202.227",9000)

res = mc.get_angles()
print(res)

mc.send_angles([0,10,0,20,0,100],20)
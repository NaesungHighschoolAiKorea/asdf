from flask import Flask, request, jsonify
import os
import threading
import requests

from robot import greet
from mx import dispense

app = Flask(__name__)
PC = os.getenv("PC_URL", "http://127.0.0.1:5000").rstrip("/")

# ===== MyCobot 280 연결 모드 =====
# 'serial' (기본값): 지금까지처럼 USB/UART 시리얼로 연결 (예: MyCobot 280 Pi의 /dev/ttyAMA0)
# 'wifi'            : M5 컨트롤러가 켜져 있는 TCP 소켓 서버(기본 포트 9000)에 Wi-Fi로 접속
MYCOBOT_MODE = os.getenv("MYCOBOT_MODE", "serial").strip().lower()
PORT = os.getenv("MYCOBOT_PORT", "/dev/ttyAMA0")
BAUD = int(os.getenv("MYCOBOT_BAUD", "1000000"))
MYCOBOT_WIFI_IP = os.getenv("MYCOBOT_WIFI_IP", "").strip()
MYCOBOT_WIFI_PORT = int(os.getenv("MYCOBOT_WIFI_PORT", "9000"))

try:
    if MYCOBOT_MODE == "wifi":
        from pymycobot import MyCobot280Socket
        if not MYCOBOT_WIFI_IP:
            raise RuntimeError("MYCOBOT_MODE=wifi 인데 MYCOBOT_WIFI_IP가 비어 있습니다.")
        mc = MyCobot280Socket(MYCOBOT_WIFI_IP, MYCOBOT_WIFI_PORT)
        print(f"MyCobot Wi-Fi(소켓) 연결 완료: {MYCOBOT_WIFI_IP}:{MYCOBOT_WIFI_PORT}")
    else:
        from pymycobot import MyCobot280
        mc = MyCobot280(PORT, BAUD)
        print(f"MyCobot 시리얼 연결 완료: {PORT} @ {BAUD}")
except Exception as e:
    mc = None
    print("MyCobot 연결 실패:", e)

# 인사와 사탕 배출이 동시에 실행되어 관절 명령이 섞이지 않도록 한다.
move_lock = threading.Lock()

def run_motion(func):
    if mc is None:
        raise RuntimeError("MyCobot이 연결되지 않았습니다.")
    with move_lock:
        func(mc)

def notify_pc_done(token, action):
    if not token:
        return
    try:
        requests.post(
            PC + "/api/robot/done",
            json={"token": token, "action": action},
            timeout=5,
        )
    except requests.RequestException:
        pass

@app.post("/robot/greeting")
def greeting():
    try:
        run_motion(greet)
        return jsonify(ok=True, action="greeting")
    except Exception as e:
        return jsonify(ok=False, error=str(e), action="greeting"), 500

@app.post("/robot/dispense")
def robot_dispense():
    data = request.json or {}
    token = str(data.get("token", "robot"))
    try:
        run_motion(dispense)
        notify_pc_done(token, "fixed")
        return jsonify(ok=True, action="fixed")
    except Exception as e:
        notify_pc_done(token, "error")
        return jsonify(ok=False, error=str(e), action="fixed"), 500

@app.get("/robot/status")
def robot_status():
    return jsonify(ok=mc is not None, connected=mc is not None)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5001, debug=False)

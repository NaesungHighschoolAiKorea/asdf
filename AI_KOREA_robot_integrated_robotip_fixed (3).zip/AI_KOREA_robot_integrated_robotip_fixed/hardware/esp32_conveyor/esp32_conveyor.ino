#include <WiFi.h>
#include <WebServer.h>
#include <AccelStepper.h>

// =========================
// ESP32 #2 - Conveyor stepper / TB6600
// =========================
// ESP32 #1과 같은 전시 Wi-Fi를 사용합니다. 다른 네트워크라면 두 값을 함께 바꾸세요.
const char* SSID = "QWER";
const char* PASS = "sw02190219!!";

WebServer server(80);

const int ENABLE_PIN = 25;
const int DIR_PIN = 26;
const int STEP_PIN = 27;
// HC-SR04 #1/#2: 캔디/트레이가 가까워지면 정지 이벤트를 발생시킵니다.
// 실제 장착 높이에 맞춰 STOP_DISTANCE_CM만 조정하세요.
const int ULTRA1_TRIG = 18;
const int ULTRA1_ECHO = 19;
const int ULTRA2_TRIG = 21;
const int ULTRA2_ECHO = 22;
// HC-SR04 #1: 컨베이어 위 사탕/트레이 존재 확인용 (약 1 m)
const float PRESENCE_DISTANCE_CM = 100.0;
// HC-SR04 #2: 실제 정지 위치 확인용 (10 cm 이하)
const float STOP_DISTANCE_CM = 10.0;
// #2가 이 거리보다 멀어져야 다음 stop 이벤트를 다시 허용
const float RELEASE_DISTANCE_CM = 15.0;

AccelStepper stepper(AccelStepper::DRIVER, STEP_PIN, DIR_PIN);
float requestedSpeed = 0;
unsigned long pauseUntil = 0, lastSensorCheck = 0;
bool sensor1Near = false, sensor2Near = false;
unsigned long sensorEventSeq = 0;
int lastTriggeredSensor = 0;

void sendJson(int code, bool ok, const String& message) {
  String body = String("{\"ok\":") + (ok ? "true" : "false") +
                ",\"message\":\"" + message + "\"}";
  server.send(code, "application/json", body);
}

String getCommand() {
  String b = server.arg("plain");
  // Flask requests sends {"command": "forward"}; whitespace must not matter.
  int key = b.indexOf("\"command\"");
  if (key < 0) return "";
  int colon = b.indexOf(':', key);
  int firstQuote = b.indexOf('"', colon + 1);
  int lastQuote = b.indexOf('"', firstQuote + 1);
  if (colon < 0 || firstQuote < 0 || lastQuote < 0) return "";
  String command = b.substring(firstQuote + 1, lastQuote);
  if (command == "forward" || command == "reverse" || command == "stop") return command;
  return "";
}

void motor() {
  String command = getCommand();
  if (command == "forward") requestedSpeed = 5000;
  else if (command == "reverse") requestedSpeed = -5000;
  else if (command == "stop") requestedSpeed = 0;
  else { sendJson(400, false, "forward/reverse/stop only"); return; }
  if (command != "stop") {
    pauseUntil = 0;
  }
  sendJson(200, true, command);
}

long distanceCm(int trig, int echo) {
  digitalWrite(trig, LOW); delayMicroseconds(2);
  digitalWrite(trig, HIGH); delayMicroseconds(10); digitalWrite(trig, LOW);
  unsigned long duration = pulseIn(echo, HIGH, 30000);
  return duration ? duration / 58 : -1;
}

void sensorControl() {
  String b = server.arg("plain");
  b.replace(" ", "");
  if (b.indexOf("\"reset\":true") >= 0) {
    pauseUntil = 0;
    sensor1Near = false;
    sensor2Near = false;
    sensorEventSeq = 0;
    lastTriggeredSensor = 0;
  }
  sendJson(200, true, "sensor control updated");
}

void status() {
  String body = String("{\"ok\":true,\"message\":\"ESP32 #2 ready\",\"sensor_event_seq\":") +
    String(sensorEventSeq) + ",\"last_triggered_sensor\":" + String(lastTriggeredSensor) +
    ",\"sensor1_near\":" + (sensor1Near ? "true" : "false") +
    ",\"sensor2_near\":" + (sensor2Near ? "true" : "false") + "}";
  server.send(200, "application/json", body);
}

void setup() {
  Serial.begin(115200);
  pinMode(ENABLE_PIN, OUTPUT);
  digitalWrite(ENABLE_PIN, LOW);
  pinMode(ULTRA1_TRIG, OUTPUT); pinMode(ULTRA1_ECHO, INPUT);
  pinMode(ULTRA2_TRIG, OUTPUT); pinMode(ULTRA2_ECHO, INPUT);
  stepper.setMaxSpeed(5000);
  stepper.setSpeed(0);

  WiFi.mode(WIFI_STA);
  WiFi.begin(SSID, PASS);
  Serial.print("WiFi");
  while (WiFi.status() != WL_CONNECTED) { delay(300); Serial.print('.'); }
  Serial.println();
  Serial.print("CONVEYOR IP: "); Serial.println(WiFi.localIP());

  server.on("/motor", HTTP_POST, motor);
  server.on("/sensor/control", HTTP_POST, sensorControl);
  server.on("/status", HTTP_GET, status);
  server.begin();
  Serial.println("ESP32 #2 HTTP SERVER READY");
}

void loop() {
  server.handleClient();

  if (millis() - lastSensorCheck >= 100) {
    lastSensorCheck = millis();

    long d1 = distanceCm(ULTRA1_TRIG, ULTRA1_ECHO);
    long d2 = distanceCm(ULTRA2_TRIG, ULTRA2_ECHO);

    // #1은 '사탕/트레이가 1m 영역 안에 있는가'만 판단합니다.
    // #1 자체는 컨베이어를 멈추게 하지 않고, 정지 이벤트도 만들지 않습니다.
    bool near1 = d1 > 0 && d1 <= PRESENCE_DISTANCE_CM;
    // #2가 10cm 이하로 가까워진 순간에만 1회 정지 이벤트를 만듭니다.
    bool near2 = d2 > 0 && d2 <= STOP_DISTANCE_CM;

    if (near2 && !sensor2Near) {
      requestedSpeed = 0;
      pauseUntil = 0;
      sensorEventSeq++;
      lastTriggeredSensor = 2;
    }

    sensor1Near = near1;
    sensor2Near = near2;

    // #2가 충분히 멀어져야 다음 물체의 정지 이벤트를 허용합니다.
    if (d2 > RELEASE_DISTANCE_CM || d2 < 0) sensor2Near = false;
  }

  stepper.setSpeed(millis() < pauseUntil ? 0 : requestedSpeed);
  stepper.runSpeed();
}

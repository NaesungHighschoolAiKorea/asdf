import os, json, time, uuid, threading, re
from dotenv import load_dotenv
from pathlib import Path
import numpy as np, requests
from flask import Flask, jsonify, render_template, request
from sklearn.ensemble import RandomForestClassifier

load_dotenv(Path(__file__).parent / ".env")
app = Flask(__name__)
BASE = Path(__file__).resolve().parent
RECORDINGS = BASE / 'data' / 'recordings'
OLLAMA = os.getenv('OLLAMA_URL', 'http://127.0.0.1:5000')
MODEL = os.getenv('OLLAMA_MODEL', 'gemma3:4b')
ACTUATOR = os.getenv('ESP32_ACTUATOR_URL', os.getenv('ESP32_SOLVO_URL', 'http://127.0.0.1:5000')).rstrip('/')
CONVEYOR = os.getenv('ESP32_CONVEYOR_URL', 'http://127.0.0.1:5000').rstrip('/')
CONVEYOR_ENABLED = os.getenv('CONVEYOR_ENABLED', 'false').lower() == 'true'
ROBOT_PI = os.getenv('ROBOT_PI_URL', 'http://127.0.0.1:5000')
BUTTON_KEY = os.getenv('BUTTON_KEY', 'NSAK_BUTTON_2026')
TEST_MODE = os.getenv('TEST_MODE', 'false').lower() == 'true'
DEMO = TEST_MODE or os.getenv('DEMO_HARDWARE', 'false').lower() == 'true'
EM = ['joy', 'sad', 'angry', 'tired', 'neutral']

profiles = {'bright':'밝은 에너지형','comfort':'따뜻한 공감형','challenge':'도전 집중형','rest':'회복 우선형','steady':'안정 균형형'}
train=[([.7,.05,.05,.05,.15],'bright'),([.6,.05,.05,.1,.2],'bright'),([.15,.55,.05,.1,.15],'comfort'),([.1,.6,.05,.1,.15],'comfort'),([.1,.1,.6,.05,.15],'challenge'),([.15,.05,.55,.1,.15],'challenge'),([.1,.1,.05,.65,.1],'rest'),([.1,.1,.1,.6,.1],'rest'),([.15,.15,.05,.1,.55],'steady'),([.2,.1,.05,.1,.55],'steady')]
rf=RandomForestClassifier(n_estimators=200,class_weight='balanced',random_state=42).fit([x for x,y in train],[y for x,y in train])
sessions={}; events={}; lock=threading.Lock(); whisper=None
button_seq = 0
transcribe_lock = threading.Lock()
CIRCUIT_MAP = {'joy': 'slot1', 'sad': 'slot2', 'tired': 'slot3', 'neutral': 'slot4', 'angry': 'solenoid'}
SENSOR_STOP_TIMEOUT = int(os.getenv('SENSOR_STOP_TIMEOUT', '45'))
ROBOT_ENABLED = os.getenv('ROBOT_ENABLED', 'true').lower() == 'true'

def post(url, data=None, timeout=6):
    try:
        r=requests.post(url, json=data or {}, timeout=timeout)
        return r.ok, r.json() if r.headers.get('content-type','').startswith('application/json') else {}
    except Exception as e:
        return False, {'error': str(e)}

def get_json(url, timeout=3):
    try:
        r=requests.get(url, timeout=timeout)
        return r.ok, r.json() if r.headers.get('content-type','').startswith('application/json') else {}
    except Exception as e:
        return False, {'error': str(e)}

def hardware(path, data):
    if DEMO:
        with lock: events['demo'] = True
        return True, {'ok': True, 'demo': True}
    return post(path, data)

def ollama(prompt):
    try:
        r=requests.post(f'{OLLAMA}/api/generate',json={'model':MODEL,'prompt':prompt,'stream':False},timeout=45)
        r.raise_for_status(); return r.json().get('response','').strip()
    except Exception:return None

def fallback_emotion(t):
    s={k:.05 for k in EM}; groups={'joy':['기쁘','행복','좋아','뿌듯','기대','즐거'],'sad':['슬프','속상','아쉽','위로'],'angry':['화나','짜증','분노','열받','억울'],'tired':['피곤','지쳐','쉬고','잠'],'neutral':['평온','편안','안정','차분','담담','괜찮','여유','평범']}
    for k,ws in groups.items():
        for w in ws:
            if w in t:s[k]+=.2
    z=sum(s.values()); return {k:round(v/z,4) for k,v in s.items()}

def analyze(t):
    # neutral은 '평온/안정'을 의미한다. 판단 불가를 무조건 neutral로 찍지 않도록
    # Gemma에게 먼저 joy/sad/angry/tired/calm 중 하나를 근거와 함께 판단하게 한다.
    raw=ollama('''한국어 답변의 감정을 JSON 하나로만 출력해라.
분류는 joy, sad, angry, tired, calm 중 정확히 하나를 가장 높은 값으로 판단한다.
calm은 평온함, 편안함, 안정감, 담담함을 뜻한다. 답변에 그런 분위기가 있으면 calm을 적극적으로 사용한다.
단순히 애매하거나 정보가 부족하다는 이유로 calm을 선택하지 마라. 정말 감정 판단 자체가 어려울 때만 calm을 낮은 확률로 둔다.
형식: {"joy":0,"sad":0,"angry":0,"tired":0,"calm":0}
확률의 합은 1이다. 설명은 출력하지 마라.
답변:'''+t)
    if raw:
        try:
            d=json.loads(raw[raw.find('{'):raw.rfind('}')+1])
            # 프로젝트의 기존 5개 레이블을 유지하되 calm을 neutral로 저장한다.
            d={k:max(0,float(d.get(k,0))) for k in ['joy','sad','angry','tired','calm']}
            d['neutral']=d.pop('calm')
            z=sum(d.values()) or 1
            return {k:round(v/z,4) for k,v in d.items()}
        except Exception:
            pass
    return fallback_emotion(t)

def reason(t,e):
    r=ollama(f'너는 감정 로봇 "모노바"다. 사용자 답변에서 {e} 감정을 가장 높게 판단한 근거를 30~50자의 자연스러운 한국어 반말 한 문장으로 써라. 없는 사실은 만들지 마라. 답변:{t}')
    return r or f'네 답변에서 {e}와 관련된 표현이 많이 느껴져서 모노바가 그렇게 판단했어.'

def reply(t):
    r=ollama(f'너는 "AI KOREA" 전시장의 감정 로봇 "모노바"다. 1인칭으로, 반말로, 다정하고 따뜻하게 2~3문장으로 다음 답변에 공감하고 이제 감정을 분석해보겠다고 예고해라. 진단하지 마라. 답변:{t}')
    return r or '그 이야기 잘 들었어! 모노바가 방금 들은 표현을 바탕으로 감정을 분석해볼게.'

def dispense_servo(slot, emotion='neutral'):
    return hardware(ACTUATOR + '/dispense', {'slot': int(slot), 'emotion': emotion})

def conveyor(command):
    if not CONVEYOR_ENABLED:
        return False, {'error': '컨베이어는 현재 비활성화되어 있습니다.'}
    return hardware(CONVEYOR + '/motor', {'command': command})

def signal(slot, emotion):
    ok, result = dispense_servo(slot, emotion)
    return ok, result

def circuit_action(emotion):
    action = CIRCUIT_MAP.get(emotion, 'slot4')
    if action == 'solenoid':
        return {'action': 'solenoid', 'slot': None}
    return {'action': 'servo', 'slot': int(action[-1])}

def dispense_pair(emotions):
    """두 감정 회로를 한 번의 HTTP 요청으로 거의 동시에 작동시킨다."""
    a, b = [circuit_action(e) for e in emotions]
    # 같은 슬롯이 겹치면 중복 작동 대신 한 번만 작동시킨다.
    if a == b:
        return signal(a['slot'], emotions[0]) if a['slot'] else hardware(ACTUATOR + '/solenoid', {'duration': 600})
    return hardware(ACTUATOR + '/dispense_pair', {
        'slot_a': a['slot'] or 0,
        'slot_b': b['slot'] or 0,
        'action_a': a['action'],
        'action_b': b['action'],
        'emotion_a': emotions[0],
        'emotion_b': emotions[1],
    })

def sensor_snapshot():
    return get_json(CONVEYOR + '/status', timeout=2)

def wait_for_sensor_event(previous_seq, timeout=SENSOR_STOP_TIMEOUT):
    """HC-SR04 #2의 새 정지 이벤트를 기다린다."""
    deadline = time.time() + timeout
    while time.time() < deadline:
        ok, status = sensor_snapshot()
        if ok and int(status.get('sensor_event_seq', 0)) > previous_seq:
            return True, status
        time.sleep(0.12)
    return False, {'error': '초음파 #2 정지 신호를 제한 시간 안에 받지 못했습니다.'}

def wait_for_candy_presence(timeout=SENSOR_STOP_TIMEOUT):
    """HC-SR04 #1(약 1 m)에서 컨베이어 위 사탕/트레이가 감지될 때까지 기다린다."""
    deadline = time.time() + timeout
    while time.time() < deadline:
        ok, status = sensor_snapshot()
        if ok and bool(status.get('sensor1_near', False)):
            return True, status
        time.sleep(0.12)
    return False, {'error': '초음파 #1(1m)에서 사탕/트레이를 감지하지 못했습니다.'}

def wait_for_candy_clear(timeout=SENSOR_STOP_TIMEOUT):
    """로봇 동작 후 HC-SR04 #1의 1m 영역에서 사탕/트레이가 사라질 때까지 기다린다."""
    deadline = time.time() + timeout
    while time.time() < deadline:
        ok, status = sensor_snapshot()
        if ok and not bool(status.get('sensor1_near', False)):
            return True, status
        time.sleep(0.12)
    return False, {'error': '초음파 #1(1m)에서 사탕/트레이가 빠져나가는 것을 확인하지 못했습니다.'}

def robot_greeting():
    """첫 화면에서 s-main/robot.py의 인사 동작을 실행한다."""
    if DEMO or not ROBOT_ENABLED:
        return True, {'ok': True, 'demo': True, 'action': 'greeting'}
    return post(ROBOT_PI.rstrip('/') + '/robot/greeting', {}, timeout=30)


def robot_run():
    """MyCobot은 감정/슬롯과 무관하게 항상 하나의 고정 동작만 수행한다."""
    if DEMO or not ROBOT_ENABLED:
        return True, {'ok': True, 'demo': True, 'action': 'fixed'}
    return post(ROBOT_PI.rstrip('/') + '/robot/dispense', {'action': 'fixed'}, timeout=30)

def dispense_once(emotions):
    """한 정지 지점에서 디스펜서 명령은 정확히 한 번만 보낸다.
    Q2/Q4는 두 회로를 한 요청으로 거의 동시에, Q5는 한 회로를 한 번 작동시킨다.
    """
    if len(emotions) == 2:
        return dispense_pair(emotions)
    action = circuit_action(emotions[0])
    if DEMO:
        return True, {'ok': True, 'demo': True, 'action': action}
    if action['action'] == 'solenoid':
        return hardware(ACTUATOR + '/solenoid', {'duration': 600})
    return signal(action['slot'], emotions[0])

def run_circuit_cycle(token, emotions):
    """사탕 1개(또는 같은 정지 지점에서 선택된 2회로)를 한 번만 배출한다.

    실제 순서:
      1) 컨베이어 시작
      2) 초음파 #1(약 1m)에서 사탕/트레이 존재 확인
      3) 초음파 #2(10cm 이하) 새 감지 이벤트까지 이동
      4) 컨베이어 정지
      5) 디스펜서 명령 1회
      6) MyCobot 고정 동작 1회
      7) 컨베이어 재시작
      8) 초음파 #1(1m) 영역에서 사탕/트레이가 사라지는 것을 확인
      9) 컨베이어 정지 및 완료

    디스펜서를 두 번 작동시키지 않는다.
    """
    try:
        if not CONVEYOR_ENABLED:
            # 테스트/데모에서는 센서가 없어도 실제 순서를 1회만 시뮬레이션한다.
            ok, result = dispense_once(emotions)
            if not ok:
                raise RuntimeError(result.get('error', '디스펜서 작동 실패'))
            ok, result = robot_run()
            if not ok:
                raise RuntimeError(result.get('error', '로봇팔 작동 실패'))
            with lock:
                events[token] = {'done': True, 'demo': True, 'stops': 1,
                                 'dispense_count': 1, 'emotions': emotions}
            return

        # 이전 센서 상태를 깨끗하게 만들고 컨베이어를 시작한다.
        ok, result = post(CONVEYOR + '/sensor/control', {'reset': True})
        if not ok:
            raise RuntimeError(result.get('error', '초음파 센서 초기화 실패'))

        ok, result = conveyor('forward')
        if not ok:
            raise RuntimeError(result.get('error', '컨베이어 시작 실패'))

        # 1단계: 1m 센서가 사탕/트레이 존재를 확인할 때까지 이동.
        present, status = wait_for_candy_presence()
        if not present:
            conveyor('stop')
            raise RuntimeError(status.get('error', '초음파 #1 사탕 감지 실패'))

        # 2단계: 10cm 센서의 새 감지 이벤트를 기다린다.
        ok, before = sensor_snapshot()
        previous_seq = int(before.get('sensor_event_seq', 0)) if ok else 0
        stopped, sensor = wait_for_sensor_event(previous_seq)
        if not stopped:
            conveyor('stop')
            raise RuntimeError(sensor.get('error', '초음파 #2 정지 신호 대기 실패'))

        # 3단계: 10cm 센서가 잡은 위치에서 컨베이어를 멈춘다.
        ok, result = conveyor('stop')
        if not ok:
            raise RuntimeError(result.get('error', '컨베이어 정지 실패'))

        # 4단계: 디스펜서는 이 사이클에서 정확히 한 번만 호출한다.
        ok, result = dispense_once(emotions)
        if not ok:
            conveyor('stop')
            raise RuntimeError(result.get('error', '디스펜서 작동 실패'))

        # 5단계: 로봇팔도 항상 같은 동작을 정확히 한 번 수행한다.
        ok, result = robot_run()
        if not ok:
            conveyor('stop')
            raise RuntimeError(result.get('error', '로봇팔 작동 실패'))

        # 6단계: 로봇이 끝난 뒤 컨베이어를 다시 움직인다.
        ok, result = conveyor('forward')
        if not ok:
            conveyor('stop')
            raise RuntimeError(result.get('error', '컨베이어 재시작 실패'))

        # 7단계: 1m 센서에서 사탕/트레이가 빠져나간 것을 확인한다.
        clear, status = wait_for_candy_clear()
        if not clear:
            conveyor('stop')
            raise RuntimeError(status.get('error', '초음파 #1 사탕 이탈 확인 실패'))

        # 8단계: 다음 질문/단계로 넘어가기 전에 컨베이어를 정지한다.
        ok, result = conveyor('stop')
        if not ok:
            raise RuntimeError(result.get('error', '최종 컨베이어 정지 실패'))

        with lock:
            events[token] = {'done': True, 'stops': 1, 'dispense_count': 1,
                             'emotions': emotions}
    except Exception as e:
        conveyor('stop')
        with lock:
            events[token] = {'done': True, 'error': str(e), 'dispense_count': 0}

@app.get('/')
def index(): return render_template('index.html', test_mode=TEST_MODE)

@app.post('/api/session/start')
def start():
    sid=str(uuid.uuid4()); sessions[sid]={'history':[]};
    with lock: current_seq = button_seq
    return jsonify(session_id=sid, button_seq=current_seq)

@app.post('/api/transcribe')
def transcribe():
    global whisper
    f=request.files.get('audio')
    if not f:return jsonify(error='audio 파일이 없습니다.'),400
    # 매 녹음마다 완전히 새로운 파일명을 사용하고, 임시 파일로 먼저 저장한 뒤
    # 최종 .webm으로 원자적으로 교체한다. 연속 녹음 시 이전 파일/업로드와
    # 겹치거나 아직 저장 중인 파일을 Whisper가 읽는 문제를 방지한다.
    RECORDINGS.mkdir(parents=True, exist_ok=True)
    session_id = (request.form.get('session_id') or 'no_session').strip()
    safe_session = re.sub(r'[^A-Za-z0-9_-]', '_', session_id)[:64] or 'no_session'
    session_dir = RECORDINGS / safe_session
    session_dir.mkdir(parents=True, exist_ok=True)
    # 브라우저가 보낸 녹음 번호/객체 ID를 파일명에 포함하되,
    # UUID를 함께 사용해 같은 번호의 재녹음도 충돌하지 않게 한다.
    recording_id = (request.form.get('recording_id') or uuid.uuid4().hex).strip()
    recording_no = (request.form.get('recording_no') or '0').strip()
    safe_id = re.sub(r'[^A-Za-z0-9_-]', '_', recording_id)[:48]
    safe_no = re.sub(r'[^0-9]', '', recording_no) or '0'
    file_id = f"recording_{safe_no}_{safe_id}_{uuid.uuid4().hex[:8]}"

    tmp = session_dir / (file_id + '.uploading')
    p = session_dir / (file_id + '.webm')

    try:
        f.save(tmp)

        # Windows/백신/파일 시스템 지연까지 고려해 최종 파일이 실제로 보일 때까지 확인.
        for _ in range(20):
            if tmp.exists() and tmp.is_file() and tmp.stat().st_size > 0:
                break
            time.sleep(0.05)

        if not tmp.exists():
            return jsonify(error='녹음 WebM 임시 파일이 저장되지 않았습니다. 다시 녹음해주세요.'), 500

        os.replace(tmp, p)

        # Whisper 호출 직전 최종 파일의 존재와 크기를 다시 확인한다.
        for _ in range(20):
            if p.exists() and p.is_file() and p.stat().st_size > 0:
                break
            time.sleep(0.05)

        if not p.exists():
            return jsonify(error='녹음된 WebM 파일을 찾을 수 없습니다. 다시 녹음해주세요.'), 500

        if p.stat().st_size < 1024:
            return jsonify(error='녹음 파일이 너무 짧거나 비어 있습니다. 녹음을 시작한 뒤 2초 이상 말하고 다시 버튼을 눌러 종료해주세요.'),400
        from faster_whisper import WhisperModel
        if whisper is None: whisper=WhisperModel(os.getenv('STT_MODEL','small'),device=os.getenv('STT_DEVICE','cpu'),compute_type=os.getenv('STT_COMPUTE_TYPE','int8'))
        # 짧은 한국어 답변은 VAD가 음성 전체를 무음으로 버리는 경우가 있어 기본값을 끈다.
        vad_filter=os.getenv('STT_VAD_FILTER', 'false').lower() == 'true'
        # Whisper 인스턴스는 동시에 여러 요청이 들어오지 않도록 직렬화한다.
        with transcribe_lock:
            segments,_=whisper.transcribe(
                str(p), language='ko', vad_filter=vad_filter,
                beam_size=int(os.getenv('STT_BEAM_SIZE', '5')),
                condition_on_previous_text=False,
            )
        text=' '.join(segment.text.strip() for segment in segments).strip()
        return jsonify(
            text=text,
            recording_no=safe_no,
            recording_id=safe_id,
            file=file_id + '.webm'
        ) if text else (
            jsonify(error='음성이 인식되지 않았습니다. 다시 또렷하게 말한 뒤 녹음 종료 버튼을 눌러주세요.'),
            400
        )
    except Exception as e:
        if 'End of file' in str(e):
            return jsonify(error='녹음 파일을 읽을 수 없습니다. 녹음을 다시 시작한 뒤 2초 이상 말하고 종료해주세요.'),400
        return jsonify(error=f'음성 인식 오류: {e}'),500
    finally:
        # 업로드 중 임시 파일이 남더라도 다음 녹음에 영향을 주지 않게 정리한다.
        tmp.unlink(missing_ok=True)
        # 현장 점검용으로 원본을 보관한다. 운영 시 false로 바꾸면 성공 파일은 삭제된다.
        if os.getenv('KEEP_RECORDINGS', 'true').lower() != 'true':
            p.unlink(missing_ok=True)

@app.post('/api/respond')
def respond():
    t=(request.json or {}).get('text','').strip()
    if not t:
        return jsonify(error='text가 없습니다.'), 400
    return jsonify(response=reply(t))

@app.post('/api/analyze')
def api_analyze():
    t=(request.json or {}).get('text','').strip()
    if not t:
        return jsonify(error='text가 없습니다.'), 400
    e=analyze(t)
    d=max(e,key=e.get)
    return jsonify(emotion=e,dominant=d,reason=reason(t,d))

@app.post('/api/bonus')
def bonus():
    # 최종 결과 뒤에 보여주는 전시용 보너스 메시지.
    d=request.json or {}
    history=d.get('history', [])
    profile=d.get('profile','')
    dominant=d.get('dominant','neutral')

    if not history:
        return jsonify(
            title='오늘의 한마디',
            message='오늘 답변을 들려줘서 고마워, 모노바가 잘 기억해둘게!',
            tip='잠깐 쉬면서 오늘 좋았던 순간 하나 떠올려볼래?'
        )

    prompt = f'''
너는 "AI KOREA" 전시장의 감정 로봇 "모노바"다. 보너스 화면에 들어갈 짧은 한국어 문구를 JSON 하나로만 출력해라.
message와 tip은 모노바가 1인칭으로 반말로 다정하게 말하듯 써라 (예: "~야", "~해볼래?").
사용자의 감정을 진단하거나 단정하지 말고, 답변에 드러난 분위기를 가볍게 반영해라.
정서적으로 부담을 주지 말고 따뜻하고 밝게 써라.
반드시 다음 형식만 사용:
{{"title":"8~16자 제목","message":"2문장 이내의 응원 문구","tip":"실제로 할 수 있는 작고 안전한 제안 1문장"}}
감정: {dominant}
프로필: {profile}
답변 요약 데이터: {json.dumps(history, ensure_ascii=False)[:3500]}
'''
    raw=ollama(prompt)
    if raw:
        try:
            b=json.loads(raw[raw.find('{'):raw.rfind('}')+1])
            return jsonify(
                title=str(b.get('title') or '오늘의 한마디')[:60],
                message=str(b.get('message') or '')[:500],
                tip=str(b.get('tip') or '')[:300]
            )
        except Exception:
            pass

    fallback={
        'joy': ('좋은 에너지를 발견했어요', '네가 들려준 좋은 순간 이야기, 모노바도 기분이 좋아졌어!', '오늘 기억에 남는 좋은 순간, 모노바처럼 오래 간직해봐.'),
        'sad': ('천천히 쉬어가는 시간', '조금 무거운 이야기도 솔직하게 들려줘서 고마워.', '오늘은 잠깐 쉬면서 편안한 일을 하나 골라볼래?'),
        'angry': ('답답함도 하나의 신호예요', '마음에 걸리는 이야기를 차분하게 들려줘서 고마워.', '잠깐 자리를 바꾸거나 깊게 숨을 쉬며 기분을 환기해봐.'),
        'tired': ('오늘은 잠깐 쉬어가요', '피곤한 마음까지 솔직하게 이야기해준 게 모노바한텐 의미 있었어.', '잠깐 화면에서 눈을 떼고 편하게 쉬어봐.'),
        'neutral': ('오늘의 균형을 기록했어요', '차분하게 자신의 상태를 돌아본 시간, 모노바가 잘 담아뒀어.', '오늘 있었던 작은 즐거움 하나를 기억해둬봐.')
    }
    title,message,tip=fallback.get(dominant, fallback['neutral'])
    return jsonify(title=title,message=message,tip=tip)

@app.post('/api/final-profile')
def final_profile():
    h=(request.json or {}).get('history',[])
    if len(h) != 5:
        return jsonify(error='5개 질문의 답변이 필요합니다.'),400
    avg={k:sum(float(x.get(k,0)) for x in h)/len(h) for k in EM}; x=np.array([[avg[k] for k in EM]]);p=rf.predict(x)[0]
    return jsonify(average=avg,dominant=max(avg,key=avg.get),profile=p,profile_name=profiles[p],confidence=float(max(rf.predict_proba(x)[0])))

@app.post('/api/robot/greeting')
def greeting():
    # 첫 화면 진입 시 MyCobot 인사 동작.
    ok, result = robot_greeting()
    return jsonify(ok=ok, action='greeting', hardware=result), (200 if ok else 503)


@app.post('/api/robot/dispense')
def dispense():
    # MyCobot은 감정/슬롯과 무관하게 하나의 고정 동작만 수행한다.
    ok,result=robot_run()
    return jsonify(ok=ok, action='fixed', hardware=result)

@app.post('/api/circuit-cycle')
def circuit_cycle():
    emotions=(request.json or {}).get('emotions', [])
    if not isinstance(emotions, list) or len(emotions) not in (1, 2) or any(x not in EM for x in emotions):
        return jsonify(error='감정은 1개(Q5) 또는 2개(Q2/Q4)가 필요합니다.'), 400
    token=str(uuid.uuid4())
    with lock: events[token]={'done': False}
    threading.Thread(target=run_circuit_cycle, args=(token, emotions), daemon=True).start()
    return jsonify(ok=True, token=token, circuits=[CIRCUIT_MAP[x] for x in emotions])

@app.post('/api/conveyor')
def api_conveyor():
    if not CONVEYOR_ENABLED:
        return jsonify(ok=False, error='컨베이어는 현재 사용하지 않습니다.'), 503
    command=str((request.json or {}).get('command','stop')).lower()
    if command not in ('forward','reverse','stop'): return jsonify(ok=False,error='command는 forward/reverse/stop'),400
    ok,result=conveyor(command); return jsonify(ok=ok,hardware=result)

@app.post('/api/ui/button')
def ui_button():
    d=request.json or {}
    if d.get('key') != BUTTON_KEY: return jsonify(ok=False,error='인증 실패'),401
    action=d.get('action','')
    if action.startswith('slot'):
        try:
            slot=int(action[4:])
        except (ValueError, TypeError):
            return jsonify(ok=False,error='잘못된 slot'),400
        if slot not in range(1,5): return jsonify(ok=False,error='slot 1~4'),400
        ok,result=signal(slot,d.get('emotion','neutral')); return jsonify(ok=ok,action=action,hardware=result)
    if action in ('conveyor_start','conveyor_stop','conveyor_reverse'):
        if not CONVEYOR_ENABLED:
            return jsonify(ok=False, error='컨베이어는 현재 사용하지 않습니다.'), 503
        cmd={'conveyor_start':'forward','conveyor_stop':'stop','conveyor_reverse':'reverse'}[action]
        ok,result=conveyor(cmd); return jsonify(ok=ok,action=action,hardware=result)
    if action == 'solenoid':
        ok,result=post(ACTUATOR+'/solenoid',{'duration':1000}) if not DEMO else (True,{'ok':True,'demo':True})
        return jsonify(ok=ok,action=action,hardware=result)
    if action in ('dc_forward', 'dc_stop', 'dc_reverse'):
        command={'dc_forward':'forward','dc_stop':'stop','dc_reverse':'reverse'}[action]
        ok,result=hardware(ACTUATOR + '/dc', {'command': command, 'speed': 180})
        return jsonify(ok=ok,action=action,hardware=result)
    return jsonify(ok=False,error='알 수 없는 action'),400

@app.route('/api/ui/record', methods=['GET', 'POST'])
def ui_record():
    """ESP32 물리 버튼의 눌림을 단발성 이벤트 번호로 전달한다.
    버튼 released 상태를 감시하지 않기 때문에 polling 타이밍으로 녹음이 재토글되지 않는다.
    """
    global button_seq
    if request.method == 'POST':
        data=request.json or {}
        if data.get('key') != BUTTON_KEY:
            return jsonify(ok=False,error='인증 실패'),401
        state=data.get('state')
        if state not in ('pressed','released'):
            return jsonify(ok=False,error='state는 pressed 또는 released'),400
        if state == 'pressed':
            with lock:
                button_seq += 1
                seq = button_seq
            return jsonify(ok=True,button_seq=seq,event='pressed')
        with lock:
            seq = button_seq
        return jsonify(ok=True,button_seq=seq,event='released')
    with lock:
        seq = button_seq
    return jsonify(ok=True,button_seq=seq)

@app.get('/api/robot/status')
def status():
    token=request.args.get('token', 'demo')
    with lock: state=events.get(token, {'done': False})
    if isinstance(state, bool): state={'done': state}
    return jsonify(**state)

@app.get('/api/hardware/status')
def hardware_status():
    if DEMO:
        return jsonify(ok=True, demo=True, actuator=True, conveyor=CONVEYOR_ENABLED)
    a_ok, a = get_json(ACTUATOR + '/status')
    if not CONVEYOR_ENABLED:
        return jsonify(ok=bool(a_ok), actuator=bool(a_ok), conveyor=False,
                       actuator_detail=a, conveyor_detail={'disabled': True})
    c_ok, c = get_json(CONVEYOR + '/status')
    return jsonify(ok=bool(a_ok and c_ok), actuator=bool(a_ok),
                   conveyor=bool(c_ok), actuator_detail=a, conveyor_detail=c)

@app.post('/api/robot/done')
def done():
    token=(request.json or {}).get('token','demo')
    with lock: events[token]=True
    return jsonify(ok=True)

@app.get('/api/health')
def health():
    return jsonify(
        ok=True,
        actuator=ACTUATOR,
        conveyor=CONVEYOR,
        conveyor_enabled=CONVEYOR_ENABLED,
        button_key_configured=bool(BUTTON_KEY),
        demo=DEMO,
    )

@app.post('/api/session/finish')
def finish(): return jsonify(ok=True)

if __name__=='__main__': app.run(host='0.0.0.0',port=5000,debug=False)

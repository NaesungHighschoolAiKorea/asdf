GIF 자리입니다.

STT 대기 화면: static/gif/stt.gif
로봇 대기 화면: static/gif/robot.gif

원하는 GIF 파일을 위 이름으로 넣으면 자동으로 표시됩니다.
파일이 없으면 내장 애니메이션이 대신 표시됩니다.

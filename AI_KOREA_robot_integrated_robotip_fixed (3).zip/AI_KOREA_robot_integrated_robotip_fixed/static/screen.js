(() => {
  'use strict';

  // 질문은 감정별로 묶어 두고, 한 세션에서는 중복 없이 랜덤으로 선택한다.
  // Gemini가 매번 질문을 생성하게 하지 않는 이유: 전시에서 지연/실패가 생기면
  // 질문 흐름 자체가 멈출 수 있기 때문이다. 필요하면 나중에 '후속 질문'만 AI로 붙일 수 있다.
  // 질문은 특정 감정을 유도하지 않도록 소재를 중립적으로 구성한다.
  // 한 세션에서는 5개 카테고리에서 하나씩 뽑은 뒤 순서를 섞는다.
  const QUESTION_POOLS = {
    experience: [
      '최근 기억에 남는 일이 있다면 어떤 일이었나요?',
      '최근 일상에서 인상 깊었던 순간은 언제였나요?',
      '요즘 떠올리면 기억에 남는 장면이 있나요?'
    ],
    routine: [
      '요즘 가장 자주 하고 있는 일은 무엇인가요?',
      '최근 하루를 보내는 방식은 어떤가요?',
      '요즘 시간을 가장 많이 보내는 곳은 어디인가요?'
    ],
    thought: [
      '요즘 가장 많이 떠올리는 생각은 무엇인가요?',
      '최근 관심이 가는 것이 있다면 무엇인가요?',
      '요즘 새롭게 생각해보게 된 것이 있나요?'
    ],
    people: [
      '최근 누군가와 나눈 대화 중 기억에 남는 것이 있나요?',
      '요즘 주변 사람들과 주로 어떤 이야기를 나누나요?',
      '최근 다른 사람과 함께했던 일 중 떠오르는 것이 있나요?'
    ],
    change: [
      '최근 일상에서 달라진 점이 있다면 무엇인가요?',
      '요즘 새롭게 시작했거나 바뀐 일이 있나요?',
      '최근 예상하지 못했던 일이 있었다면 어떤 일이었나요?'
    ]
  };

  function pickQuestions() {
    const pools = Object.values(QUESTION_POOLS).map(pool => pool[Math.floor(Math.random() * pool.length)]);
    // 첫 5개를 섞되 한 번의 체험에서는 감정 카테고리가 골고루 등장하도록 한다.
    for (let i = pools.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [pools[i], pools[j]] = [pools[j], pools[i]];
    }
    return pools;
  }

  let QUESTIONS = pickQuestions();
  const TEST_MODE = document.documentElement.dataset.testMode === 'true';

  // 시작 화면에서 하드웨어 버튼을 누르면 보여줄 모노바의 인사말.
  // 문장 단위로 타이핑 애니메이션으로 등장한다.
  const GREETING_LINES = [
    '안녕! 내 이름은 모노바야 🤖',
    '나는 너의 말에 따라 감정을 분석하고 간식을 줄게!',
    '시작하고 싶다면 아래 빨간 큰 버튼을 눌러줘!'
  ];

  const state = {
    sessionId: null,
    questionIndex: 0,
    history: [],
    currentText: '',
    busy: false,
    recording: false,
    remoteReady: false,
    nextLocked: false,
    recordingStartedAt: 0,
    recordingTimer: null,
    recordingSource: null,
    recordingNo: 0,
    activeRecording: null,
    lastButtonSeq: 0,
    buttonPolling: false,
    finishing: false,
    robotReady: false,
    testMode: TEST_MODE,
    greetingShown: false,
    greetingBusy: false,
    finalDominant: ''
  };

  const $ = id => document.getElementById(id);
  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

  function microphoneUnavailableMessage() {
    return '모노바가 마이크를 쓰려면 HTTPS 또는 이 PC의 http://localhost:5000 으로 접속해야 해요.';
  }

  function showScreen(id) {
    document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
    const target = $(id);
    if (target) target.classList.add('active');
  }

  function setBusy(busy) {
    state.busy = busy;
    ['recordButton','textSubmitButton','startButton','nextButton','homeButton','bonusButton'].forEach(id => {
      const el = $(id);
      if (el) el.disabled = busy;
    });
  }

  function renderQuestion() {
    const n = state.questionIndex;
    $('qnum').textContent = `${n + 1} / ${QUESTIONS.length}`;
    $('qtext').textContent = QUESTIONS[n];
    $('progress').style.width = `${((n + 1) / QUESTIONS.length) * 100}%`;
    $('status').textContent = '버튼을 한 번 누르면 모노바가 녹음을 시작할게!';
    $('textAnswer').value = '';
    $('textAnswerWrap').hidden = window.isSecureContext;
    $('recordButton').disabled = true;
    $('recordButton').textContent = '🎙️ 버튼을 누르면 모노바가 들을게';
    $('recordButton').classList.remove('recording');
    $('remoteRecordButton').textContent = '🤖 모노바가 버튼을 기다리고 있어요';
    $('remoteRecordButton').disabled = true;
    $('questionBadge').textContent = `🤖 QUESTION ${String(n + 1).padStart(2, '0')}`;
  }

  async function postJSON(url, data) {
    const r = await fetch(url, {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify(data),
      cache: 'no-store'
    });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(d.error || `HTTP ${r.status}`);
    return d;
  }

  async function start() {
    if (state.busy) return;
    setBusy(true);
    try {
      const d = await postJSON('/api/session/start', {});
      state.sessionId = d.session_id;
      QUESTIONS = Array.isArray(d.questions) && d.questions.length === 5 ? d.questions : pickQuestions();
      state.questionIndex = 0;
      state.history = [];
      state.currentText = '';
      state.recordingNo = 0;
      state.lastButtonSeq = Number(d.button_seq || 0);
      state.robotReady = false;
      state.testMode = Boolean(d.test_mode);
      renderQuestion();
      showScreen('question');
    } catch (e) {
      alert(e.message);
    } finally {
      setBusy(false);
    }
  }

  async function transcribeBlob(blob, recordInfo) {
    const fd = new FormData();
    fd.append('audio', blob, `recording_${String(recordInfo.number).padStart(2, '0')}_${recordInfo.id}.webm`);
    fd.append('session_id', state.sessionId || '');
    fd.append('recording_id', String(recordInfo.id));
    fd.append('recording_no', String(recordInfo.number));
    fd.append('question_no', String(state.questionIndex + 1));

    const r = await fetch('/api/transcribe', {method:'POST', body:fd, cache:'no-store'});
    const d = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(d.error || '음성 인식 실패');
    return d.text || '';
  }

  async function submitAnswer(text, allowBusy = false) {
    if (state.busy && !allowBusy) return false;
    text = (text || '').trim();
    if (!text) throw new Error('음성이 인식되지 않았습니다.');

    state.currentText = text;
    if (!allowBusy) setBusy(true);

    const [response, analysis] = await Promise.all([
      postJSON('/api/respond', {text}),
      postJSON('/api/analyze', {text})
    ]);

    state.history.push({
      question: QUESTIONS[state.questionIndex],
      question_no: state.questionIndex + 1,
      text,
      ...analysis.emotion,
      dominant: analysis.dominant
    });

    $('empathyText').textContent = response.response;
    $('reasonBox').textContent = analysis.reason || '';
    $('nextButton').textContent = state.questionIndex === QUESTIONS.length - 1 ? '버튼을 누르면 모노바의 최종 결과 보기' : '버튼을 누르면 모노바랑 다음 질문';
    $('nextButton').disabled = true;
    showScreen('empathy');
    return true;
  }

  function showSttWaiting(message = '네 목소리를 글자로 바꾸는 중이야.') {
    $('waitingTitle').textContent = '잠깐만, 모노바가 듣고 있어';
    $('waitingText').textContent = message;
    $('waitingStep').textContent = '01  목소리 확인  ·  02  글자로 변환  ·  03  모노바가 분석';
    showScreen('sttWait');
  }

  function showRecordTimer() {
    clearInterval(state.recordingTimer);
    state.recordingTimer = setInterval(() => {
      if (!state.recordingStartedAt) return;
      const sec = Math.floor((Date.now() - state.recordingStartedAt) / 1000);
      $('recordTimer').textContent = `00:${String(sec).padStart(2, '0')}`;
    }, 200);
  }

  function clearRecordTimer() {
    clearInterval(state.recordingTimer);
    state.recordingTimer = null;
  }

  class RecordingSession {
    static nextId = 1;
    constructor(source) {
      this.id = `${Date.now()}_${RecordingSession.nextId++}_${crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(16).slice(2)}`;
      this.number = state.recordingNo + 1;
      this.source = source;
      this.stream = null;
      this.recorder = null;
      this.chunks = [];
      this.startedAt = 0;
      this.stopped = false;
      this.mimeType = 'audio/webm';
      this.stopPromise = null;
    }
    async start() {
      this.stream = await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true}});
      const supported = ['audio/webm;codecs=opus','audio/webm'].find(t => MediaRecorder.isTypeSupported(t));
      this.mimeType = supported || 'audio/webm';
      this.recorder = supported ? new MediaRecorder(this.stream,{mimeType:supported}) : new MediaRecorder(this.stream);
      this.startedAt = Date.now();
      this.recorder.ondataavailable = e => { if (e.data?.size) this.chunks.push(e.data); };
      this.recorder.onerror = e => console.error('MediaRecorder error', e);
      this.stopPromise = new Promise(resolve => { this._resolveStop = resolve; });
      this.recorder.onstop = () => this._resolveStop?.();
      this.recorder.start(250);
    }
    async stop() {
      if (this.stopped || !this.recorder || this.recorder.state === 'inactive') return;
      this.stopped = true;
      this.recorder.stop();
      await this.stopPromise;
      this.closeStream();
    }
    closeStream() {
      this.stream?.getTracks().forEach(track => track.stop());
      this.stream = null;
    }
    createBlob() { return new Blob(this.chunks,{type:this.recorder?.mimeType || this.mimeType}); }
    get durationMs() { return this.startedAt ? Date.now() - this.startedAt : 0; }
  }

  async function beginRecording(source = 'remote') {
    if (state.recording || state.busy || state.finishing) return;
    if (!window.isSecureContext || !navigator.mediaDevices?.getUserMedia || !window.MediaRecorder) {
      $('status').textContent = microphoneUnavailableMessage();
      $('textAnswerWrap').hidden = false;
      return;
    }

    const session = new RecordingSession(source);
    try {
      await session.start();
      state.recordingNo = session.number;
      state.activeRecording = session;
      state.recording = true;
      state.recordingStartedAt = session.startedAt;
      $('recordButton').classList.add('recording');
      $('recordButton').textContent = '⏹️ 버튼을 누르면 모노바가 녹음을 끝낼게';
      $('status').textContent = `모노바가 듣고 있어요 (${session.number}번째 답변) — 버튼을 다시 누르면 끝나요.`;
      $('recordTimer').textContent = '00:00';
      showRecordTimer();
    } catch (e) {
      session.closeStream();
      $('status').textContent = `모노바가 마이크를 쓸 수 없어요: ${e.message || e}`;
    }
  }

  async function finishRecording() {
    const session = state.activeRecording;
    if (!state.recording || !session || state.finishing) return;
    if (session.durationMs < 500) {
      $('status').textContent = '너무 빠르게 눌렀어요. 잠시 말한 뒤 버튼을 눌러 종료해주세요.';
      return;
    }

    state.finishing = true;
    state.recording = false;
    state.activeRecording = null;
    clearRecordTimer();
    $('recordButton').classList.remove('recording');
    $('recordButton').textContent = '🎙️ 버튼을 누르면 모노바가 들을게';

    try {
      await session.stop();
      const blob = session.createBlob();
      if (blob.size < 1024) throw new Error('녹음 파일이 너무 작습니다. 다시 녹음해주세요.');

      // 녹음이 끝난 즉시 STT 대기 화면으로 이동한다.
      showSttWaiting(`${session.number}번째 답변을 잘 저장했어. 모노바가 목소리를 이해하는 중이야.`);
      setBusy(true);

      const recordInfo = {
        id: session.id,
        number: session.number,
        source: session.source,
        durationMs: session.durationMs,
        blobSize: blob.size,
        mimeType: blob.type
      };
      const text = await transcribeBlob(blob, recordInfo);
      if (!text.trim()) throw new Error('음성이 인식되지 않았습니다.');

      $('waitingText').textContent = '무슨 말인지 알겠어! 모노바가 답변을 정리하고 있어.';
      await submitAnswer(text, true);
    } catch (e) {
      console.error('recording pipeline failed:', e);
      // 실패하면 반드시 현재 질문으로 돌아간다. 질문 번호는 절대 증가시키지 않는다.
      showScreen('question');
      $('status').textContent = `앗, 잘 못 들었어: ${e.message} 다시 한 번 들려줘.`;
    } finally {
      state.finishing = false;
      setBusy(false);
      $('nextButton').disabled = true;
    }
  }

  // 물리 버튼 하나가 현재 화면의 다음 동작을 결정한다.
  async function advanceFromPhysicalButton() {
    if (state.finishing || state.busy) return;
    if (document.getElementById('question')?.classList.contains('active')) {
      if (state.recording) await finishRecording();
      else await beginRecording('remote');
      return;
    }
    if (document.getElementById('empathy')?.classList.contains('active')) {
      await next();
      return;
    }
    if (document.getElementById('robotWait')?.classList.contains('active') && state.robotReady) {
      state.robotReady = false;
      $('robotNextButton').hidden = true;
      state.questionIndex += 1;
      renderQuestion();
      showScreen('question');
    }
  }

  // 페이지 로드 시점의 button_seq를 기준으로 삼아, 로드 전에 눌렸던(오래된) 이벤트가
  // 곧바로 인사/시작을 트리거하지 않도록 한다.
  async function initButtonSeq() {
    try {
      const r = await fetch('/api/ui/record', {cache:'no-store'});
      const d = await r.json();
      state.lastButtonSeq = Number(d.button_seq || 0);
    } catch (e) {
      console.warn('button seq init failed:', e);
    }
  }

  // 물리 버튼 이벤트 하나를 현재 활성화된 화면에 따라 분배한다.
  // start 화면: 인사 → 시작 두 단계 / 그 외 화면: 기존 진행 로직.
  async function pollRemoteButton() {
    if (state.buttonPolling) return;
    state.buttonPolling = true;
    try {
      const r = await fetch('/api/ui/record', {cache:'no-store'});
      const d = await r.json();
      const seq = Number(d.button_seq || 0);
      if (seq <= state.lastButtonSeq) return;
      state.lastButtonSeq = seq;
      if ($('start')?.classList.contains('active')) {
        await handleStartScreenButton();
      } else {
        await advanceFromPhysicalButton();
      }
    } catch (e) {
      console.warn('remote button polling:', e);
    } finally {
      state.buttonPolling = false;
    }
  }

  function topEmotionFromHistory(items) {
    const totals = Object.fromEntries(['joy','sad','angry','tired','neutral'].map(k => [k, 0]));
    items.forEach(a => Object.keys(totals).forEach(k => totals[k] += Number(a[k] || 0)));
    return Object.entries(totals).sort((a,b) => b[1] - a[1]).map(([k]) => k);
  }

  async function next() {
    // 다음 질문 이동은 오직 이 물리 버튼 이벤트에서만 발생한다.
    if (state.busy || state.nextLocked || state.recording || state.finishing) return;
    state.nextLocked = true;
    $('nextButton').disabled = true;
    try {
      if (state.questionIndex < QUESTIONS.length - 1) {
        if (state.questionIndex === 1 || state.questionIndex === 3) {
          // Q2: Q1+Q2, Q4: Q3+Q4의 감정 확률을 합산해 상위 2개를 선택한다.
          const emotions = topEmotionFromHistory(state.history.slice(-2)).slice(0, 2);
          await runCircuitCycle(emotions);
          // 하드웨어가 끝났더라도 여기서 자동으로 Q3/Q5로 넘어가지 않는다.
          // 반드시 물리 버튼을 한 번 눌러 다음 질문으로 이동한다.
          return;
        }
        state.questionIndex += 1;
        renderQuestion();
        showScreen('question');
      } else {
        // Q5: 5개 답변 전체의 감정 확률을 합산해 가장 높은 감정 하나를 사용한다.
        const emotion = topEmotionFromHistory(state.history)[0] || 'neutral';
        await runCircuitCycle([emotion]);
        // Q5 하드웨어가 끝나면 최종 결과 화면으로 이동한다.
        await finishAndResult();
      }
    } catch (e) {
      showScreen('empathy');
      $('reasonBox').textContent = `모노바가 진행하다 문제가 생겼어요: ${e.message}`;
    } finally {
      state.nextLocked = false;
      $('nextButton').disabled = false;
    }
  }

  async function runCircuitCycle(emotions) {
    showScreen('robotWait');
    $('robotStatus').textContent = emotions.length === 2
      ? '모노바가 사탕 위치를 확인하고 두 가지 감정 캔디를 준비하고 있어요.'
      : '모노바가 사탕 위치를 확인하고 마지막 감정 캔디를 준비하고 있어요.';
    const start = await postJSON('/api/circuit-cycle',{emotions});
    while (true) {
      await sleep(500);
      const r = await fetch(`/api/robot/status?token=${encodeURIComponent(start.token)}`,{cache:'no-store'});
      const result = await r.json();
      if (!result.done) continue;
      if (result.error) throw new Error(result.error);
      state.robotReady = true;
      $('robotStatus').textContent = '캔디 준비 끝! 버튼을 누르면 모노바랑 계속할게요.';
      $('robotNextButton').hidden = true;
      return;
    }
  }

  async function finishAndResult() {
    setBusy(true);
    showScreen('loading');
    try {
      const d = await postJSON('/api/final-profile',{history:state.history});
      state.finalDominant = d.dominant;
      $('finalTitle').textContent = `모노바가 읽은 오늘의 감정: ${d.dominant}`;
      $('profile').textContent = d.profile_name;
      $('profileReason').textContent = `다섯 가지 답변을 모두 살펴본 모노바의 결과야. 확신도 ${(d.confidence*100).toFixed(0)}%`;
      const labels=['기쁨','슬픔','분노','피로','평온'];
      const keys=['joy','sad','angry','tired','neutral'];
      const values=keys.map(k=>Number(d.average[k]||0));
      if(window.Chart){
        const canvas=$('emotionChart');
        if(window._emotionChart) window._emotionChart.destroy();
        window._emotionChart=new Chart(canvas,{type:'bar',data:{labels,datasets:[{label:'감정 비율',data:values}]},options:{responsive:true,scales:{y:{beginAtZero:true,max:1}}}});
      }
      showScreen('result');
    } finally { setBusy(false); }
  }

  async function openBonus() {
    if(state.busy || !state.history.length) return;
    setBusy(true); showScreen('bonus'); $('bonusStatus').textContent='오늘의 보너스를 준비하고 있어요...';
    try {
      const d=await postJSON('/api/bonus',{history:state.history,profile:$('profile').textContent,dominant:state.finalDominant||''});
      $('bonusTitle').textContent=d.title||'오늘의 한마디';
      $('bonusText').textContent=d.message||'모노바가 네 답변을 보고 작은 응원을 준비했어요.';
      $('bonusTip').textContent=d.tip||'잠깐 쉬어가도 괜찮아요.';
      $('bonusStatus').textContent='네 답변을 바탕으로 모노바가 만든 보너스예요.';
    } catch(e) {
      $('bonusTitle').textContent='오늘의 한마디';
      $('bonusText').textContent='오늘의 답변 하나하나가 지금의 분위기를 보여주는 소중한 기록이에요.';
      $('bonusTip').textContent='잠깐 쉬면서 오늘 좋았던 순간 하나를 떠올려보세요.';
      $('bonusStatus').textContent='모노바가 보너스 화면을 준비했어요.';
    } finally { setBusy(false); }
  }

  function home() {
    if(state.recording) finishRecording();
    state.sessionId=null; state.questionIndex=0; state.history=[]; state.currentText=''; state.nextLocked=false; state.finishing=false; state.finalDominant='';
    resetStartScreen();
    showScreen('start');
  }

  // ===== 시작 화면: 하드웨어 버튼 1회 → 모노바 인사, 2회(또는 화면의 빨간 버튼) → 질문 1 =====

  function resetStartScreen() {
    // 다음 체험자를 위해 인사 상태를 초기화한다. (전시는 반복 사용되므로 필수)
    state.greetingShown = false;
    state.greetingBusy = false;
    const bubble = $('robotGreetingBubble');
    if (bubble) { bubble.hidden = true; bubble.classList.remove('show'); }
    const textEl = $('robotGreetingText');
    if (textEl) { textEl.textContent = ''; textEl.classList.remove('typing'); }
    initStartScreen();
  }

  function initStartScreen() {
    const button = $('startButton');
    const status = $('robotGreetingStatus');
    if (!button) return;
    button.disabled = true;
    button.classList.remove('ready');
    button.textContent = '로봇 인사를 기다리는 중…';
    if (status) {
      status.textContent = TEST_MODE
        ? '테스트 모드 · Space 키를 눌러 모노바의 인사를 들어보세요.'
        : '하드웨어 버튼을 한 번 눌러 모노바의 인사를 들어보세요.';
    }
  }

  async function typeLine(el, text, speed = 26) {
    for (const ch of text) {
      el.textContent += ch;
      await sleep(speed);
    }
  }

  async function revealGreetingBubble() {
    const bubble = $('robotGreetingBubble');
    const textEl = $('robotGreetingText');
    if (!bubble || !textEl) return;
    textEl.textContent = '';
    bubble.hidden = false;
    // 다음 프레임에 클래스를 추가해야 CSS 트랜지션(등장 애니메이션)이 확실히 재생된다.
    requestAnimationFrame(() => bubble.classList.add('show'));
    await sleep(120);
    textEl.classList.add('typing');
    for (let i = 0; i < GREETING_LINES.length; i++) {
      await typeLine(textEl, (i === 0 ? '' : '\n') + GREETING_LINES[i]);
      await sleep(260);
    }
    textEl.classList.remove('typing');
  }

  // 하드웨어 버튼 1회째: 로봇팔 인사 동작 + 화면 인사말을 함께 재생한다.
  async function showRobotGreeting() {
    if (state.greetingShown || state.greetingBusy) return;
    state.greetingBusy = true;
    const status = $('robotGreetingStatus');
    const button = $('startButton');
    try {
      if (status) status.textContent = '모노바가 인사하고 있어요…';
      // 로봇팔 인사 동작은 화면 애니메이션과 동시에, 결과를 기다리지 않고 요청한다.
      // (로봇이 없거나 응답이 늦어도 화면 진행은 막히지 않는다.)
      postJSON('/api/robot/greeting', {}).catch(e => console.warn('robot greeting:', e));
      await revealGreetingBubble();
      state.greetingShown = true;
      if (status) status.textContent = '아래 빨간 큰 버튼을 눌러 체험을 시작해요!';
      if (button) {
        button.disabled = false;
        button.classList.add('ready');
        button.textContent = '시작하기 →';
      }
    } finally {
      state.greetingBusy = false;
    }
  }

  // 시작 화면에서의 물리 버튼(또는 TEST_MODE의 Space) 1회 입력을 처리한다.
  // 아직 인사를 못 봤다면 인사부터, 이미 인사를 봤다면 체험을 시작한다.
  async function handleStartScreenButton() {
    if (state.busy || state.greetingBusy) return;
    if (!state.greetingShown) {
      await showRobotGreeting();
    } else {
      await start();
    }
  }

  $('startButton').addEventListener('click',start);
  // 녹음 시작/종료는 ESP32 물리 버튼만 담당합니다. 화면 버튼은 상태 표시용입니다.
  $('recordButton').addEventListener('click', (e) => e.preventDefault());
  $('remoteRecordButton').addEventListener('click',()=>{ $('status').textContent='버튼을 누르면 모노바가 바로 들을게요.'; });
  // 전시에서는 ESP32 물리 버튼만 사용한다. TEST_MODE=true일 때만 Space로 같은 이벤트를 재현한다.
  if (!TEST_MODE) {
    initButtonSeq().then(() => setInterval(pollRemoteButton, 120));
  }

  document.addEventListener('keydown', async (e) => {
    if (!TEST_MODE || e.code !== 'Space' || e.repeat) return;
    e.preventDefault();
    try {
      // 시작 화면에서도 Space 한 번 = 물리 버튼 한 번과 동일하게 동작한다.
      if ($('start')?.classList.contains('active')) {
        await handleStartScreenButton();
        return;
      }
      await advanceFromPhysicalButton();
    } catch (err) {
      console.error('TEST_MODE keyboard event:', err);
    }
  });

  document.querySelectorAll('[data-action]').forEach(btn=>{
    btn.addEventListener('click',async()=>{
      const action=btn.dataset.action, status=$('manualStatus'); btn.disabled=true; status.textContent=`${action} 실행 중...`;
      try { const d=await postJSON('/api/ui/button',{key:'NSAK_BUTTON_2026',action,emotion:'neutral'}); status.textContent=d.ok?`${action} 완료`:`${action} 실패`; }
      catch(e){ status.textContent=`오류: ${e.message}`; }
      finally{ btn.disabled=false; }
    });
  });

  $('textSubmitButton').addEventListener('click',(e)=>{ e.preventDefault(); $('status').textContent='전시 모드에서는 모노바에게 버튼으로만 말할 수 있어요.'; });
  // 다음 질문은 웹 버튼으로 진행하지 않는다. 물리 버튼 이벤트만 next()를 호출한다.
  $('bonusButton').addEventListener('click',openBonus);
  $('bonusHomeButton').addEventListener('click',home);
  $('homeButton').addEventListener('click',home);

  renderQuestion();
  // 첫 화면 진입 시에는 아직 인사하지 않은 대기 상태로 초기화한다.
  // 실제 인사(로봇팔 동작 + 말풍선)는 하드웨어 버튼이 눌렸을 때 showRobotGreeting()에서 실행된다.
  initStartScreen();
})();

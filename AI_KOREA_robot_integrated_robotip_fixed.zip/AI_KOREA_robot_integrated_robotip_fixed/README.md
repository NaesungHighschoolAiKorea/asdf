# AI KOREA FINAL — COMPLETE SW + FINAL_HARDWARE 호환 수정본

**기존 FINAL_HARDWARE 핀을 변경하지 않았습니다.**
문제가 되었던 이전 통합본의 임의 핀 변경을 제거하고, Flask API만 하드웨어 코드와 맞췄습니다.

## ESP32 #1 — 서보 4 + 솔레노이드 + BTS7960 DC
- Servo1 SIGNAL → GPIO18
- Servo2 SIGNAL → GPIO19
- Servo3 SIGNAL → GPIO21
- Servo4 SIGNAL → GPIO22
- Relay IN → GPIO23
- BTS7960 RPWM → GPIO25
- BTS7960 LPWM → GPIO26
- BTS7960 R_EN → GPIO27
- BTS7960 L_EN → GPIO32

API:
- POST /dispense : {"slot":1}
- POST /solenoid : {"duration":1000}
- POST /dc : {"command":"forward","speed":180}
- GET /status

## ESP32 #2 — 컨베이어 / TB6600
- ENA → GPIO25
- DIR → GPIO26
- PUL/STEP → GPIO27

API:
- POST /motor : {"command":"forward"}
- POST /motor : {"command":"reverse"}
- POST /motor : {"command":"stop"}
- GET /status

## ESP32 #3 — 물리 버튼
- Record → GPIO13
- Button1 → GPIO14
- Button2 → GPIO16
- Button3 → GPIO17
- Button4 → GPIO18
- Button5 → GPIO19
- Button6 → GPIO21
- Button7 → GPIO22
- Button8 → GPIO23
- Button9 → GPIO25
- Button10 → GPIO26
- Button11 → GPIO27
- GPIO32는 이번 11개 동작 목록에서는 사용하지 않음.

버튼은 GPIO와 GND 사이에 연결하고 INPUT_PULLUP을 사용합니다.

## 소프트웨어 연결
브라우저 → Flask → ESP32 #1/#2
물리 버튼 ESP32 #3 → Flask → ESP32 #1/#2
Flask가 죽었을 때 버튼 컨트롤러는 가능한 동작에 대해 ESP32 #1/#2로 직접 요청하는 백업 경로를 사용합니다.

## 실행 순서
1. Arduino IDE에서 ESP32 보드 패키지와 `ESP32Servo`, `AccelStepper` 라이브러리를 설치합니다.
2. `hardware/esp32_soleservo`, `hardware/esp32_conveyor`, `hardware/esp32_buttons` 스케치를 각각 ESP32에 업로드합니다. 업로드 후 시리얼 모니터에 표시되는 IP를 적어 둡니다.
3. `.env.example`을 복사해 `.env`로 만들고, `ESP32_ACTUATOR_URL`과 `ESP32_CONVEYOR_URL`을 위 IP로 바꿉니다. 버튼 스케치의 `FLASK`도 Flask PC의 LAN IP로 바꿉니다.
4. PC에서 `pip install -r requirements.txt` 후 `python app.py`를 실행합니다. **녹음을 사용할 PC에서는 반드시 `http://localhost:5000`으로 접속하세요.** 다른 기기에서 접속하려면 HTTPS를 구성해야 합니다. 일반 HTTP 주소(`http://PC_IP:5000`)는 Chrome/Edge의 보안 정책상 마이크를 사용할 수 없습니다.
5. 먼저 `http://PC_IP:5000/api/hardware/status`가 `ok: true`인지 확인합니다. 장치 없이 화면만 점검할 때는 `.env`의 `DEMO_HARDWARE=true`로 설정합니다.

연결 흐름: `HTML 브라우저 → Flask :5000 → ESP32 #1/#2 :80`. 물리 버튼은 `ESP32 #3 → Flask :5000`으로 이벤트를 보내며, 녹음 버튼은 `/api/ui/record`를 통해 브라우저에 전달됩니다.

## PC .env
ESP32_ACTUATOR_URL=http://실제_ESP32_1_IP
ESP32_CONVEYOR_URL=http://실제_ESP32_2_IP
BUTTON_KEY=NSAK_BUTTON_2026
DEMO_HARDWARE=false

기존 ESP32_SOLVO_URL도 호환됩니다.

## Arduino IDE
ESP32 보드 패키지 + ESP32Servo + ArduinoJson + AccelStepper.
HTTPClient는 ESP32 보드 패키지에 포함됩니다.

## 중요
서보/모터/솔레노이드 전원은 ESP32 GPIO에서 직접 공급하지 않습니다. 드라이버와 별도 전원을 사용하세요.


## 이번 수정본 — 녹음 + 보너스
- 녹음은 **2초에서 자동 종료되지 않도록** 수정했습니다.
- 브라우저 `SpeechRecognition`을 녹음 종료의 기준에서 제거하고, `MediaRecorder → 서버 faster-whisper`를 기준으로 처리합니다.
- 녹음 종료는 녹음 버튼을 다시 누르거나 물리 녹음 버튼을 다시 눌렀을 때 이루어집니다.
- 최대 녹음 시간 제한은 없으며, 너무 빠른 더블 클릭만 방지합니다.
- 최종 결과 화면에 `✨ 보너스 보기`를 추가했습니다.
- 보너스 화면은 Gemma가 실행 중이면 답변/감정 프로필을 바탕으로 문구를 만들고, Gemma가 없어도 기본 문구로 동작합니다.
- **ESP32 핀, 하드웨어 API, 로봇/컨베이어 코드는 변경하지 않았습니다.**


## 녹음 버튼 동작
- 화면의 녹음 버튼: 클릭 1회 = 시작, 클릭 1회 = 종료
- ESP32 물리 녹음 버튼: 누름 1회 = 시작, 다음 누름 1회 = 종료
- 버튼을 놓는 `released` 이벤트는 녹음을 종료시키지 않음
- 녹음 시간 제한 없음
- 브라우저 polling과 ESP32 버튼을 동시에 사용해도 `released` 때문에 즉시 종료되지 않도록 서버에서 토글 상태를 관리

## 연속 녹음 안정성 수정
- 매 녹음마다 독립된 MediaRecorder와 chunks 배열을 사용합니다.
- `requestData()`와 `stop()`을 연속 호출하지 않아 마지막 WebM chunk 누락 가능성을 줄였습니다.
- 서버는 업로드 파일을 `.uploading` 임시 파일로 저장한 뒤 `.webm`으로 원자적 교체합니다.
- Whisper 실행 전에 WebM 파일의 존재와 실제 파일 크기를 확인합니다.
- 따라서 2번째/3번째 이후 녹음에서 이전 녹음의 파일 상태가 남아 발생하는 문제를 방지합니다.

## 녹음 객체 관리
- 각각의 녹음은 독립적인 `RecordingSession` 객체로 생성됩니다.
- 녹음 1, 2, 3, 4, 5 및 그 이후 녹음도 서로 다른 `MediaRecorder`, `chunks`, Blob을 사용합니다.
- 서버 저장 파일에도 녹음 번호와 객체 ID를 포함하여 연속 녹음 파일이 서로 덮어쓰지 않습니다.
- WebM 생성이 완료된 뒤 해당 녹음 객체의 Blob만 STT 서버로 전달합니다.

## Hardware flow (updated)

- Q2: Q1+Q2 emotion probabilities are summed; top 2 emotions are selected.
- Q4: Q3+Q4 emotion probabilities are summed; top 2 emotions are selected.
- Q5: all five answers are summed; the single highest emotion is selected.
- When a circuit cycle begins, the conveyor starts immediately.
- HC-SR04 #1/#2 produce one-shot stop events when an object enters the configured distance (default 7 cm).
- At each stop, the requested servo/solenoid dispensers are triggered from one HTTP request so they start as close to simultaneously as the hardware allows.
- After the first stop/dispense/robot cycle, the conveyor resumes and waits for the next ultrasonic stop event. After the second cycle, the conveyor is stopped.
- Q5 uses the same single selected emotion for the two physical passes.
- The stop distance is configurable in `hardware/esp32_conveyor/esp32_conveyor.ino` using `STOP_DISTANCE_CM` and `RELEASE_DISTANCE_CM`.

The exact distance must be calibrated on the physical rig. HC-SR04 sensors should not be treated as millimeter-accurate; start around 7 cm and adjust after testing the actual candy/tray geometry.


## V4 flow notes
- 녹음 시작/종료와 다음 단계 진행은 ESP32 물리 버튼 이벤트만 사용합니다.
- 녹음 종료 직후 STT 대기 화면으로 이동하며 STT 실패 시 같은 질문으로 돌아갑니다.
- 질문은 감정별 후보 풀에서 세션마다 중복 없이 랜덤 선택합니다.
- Q2/Q4: 두 질문의 감정을 합산해 상위 2개 회로를 선택하고, 초음파 정지 지점에서 두 디스펜서를 거의 동시에 작동합니다.
- Q5: 전체 5개 답변을 종합해 상위 감정 1개를 사용합니다.
- 각 배출 사이에는 컨베이어가 다시 이동하고 다음 초음파 이벤트에서 정지합니다.
- MyCobot은 감정/슬롯과 무관하게 항상 하나의 고정 동작만 수행합니다.
- Gemma 3:4B는 Ollama로 로컬 실행합니다.
- 감정 레이블의 neutral은 화면에서 '평온'으로 표시하며, Gemma에는 평온/안정/차분한 상태로 분류하도록 명시합니다.


## V5 최종 진행 순서
- 질문 5개는 특정 감정을 유도하지 않는 중립적인 질문 풀에서 세션마다 랜덤으로 선택합니다.
- Q1: 물리 버튼 → 녹음 시작 → 물리 버튼 → 녹음 종료 → STT 대기 → Whisper → Gemma 3:4B(Ollama 로컬) → 감정/응답 → 결과 화면.
- Q2 종료 후 Q1+Q2의 감정 확률 상위 2개를 선택하고 하드웨어 사이클을 실행합니다. 하드웨어 완료 뒤에도 자동으로 Q3으로 넘어가지 않으며 물리 버튼을 눌러야 합니다.
- Q3은 같은 음성 흐름으로 진행합니다.
- Q4 종료 후 Q3+Q4의 감정 확률 상위 2개를 선택하고 같은 하드웨어 사이클을 실행한 뒤 물리 버튼으로 Q5로 이동합니다.
- Q5 종료 후 Q1~Q5 전체 감정 확률을 합산해 최종 감정 1개를 선택하고 하드웨어 사이클을 실행합니다. 하드웨어 완료 직후 최종 결과 화면으로 이동합니다.
- Q2/Q4는 선택된 두 디스펜서를 한 HTTP 요청으로 거의 동시에 시작합니다. Q5는 선택된 한 감정의 회로를 두 번의 초음파 정지 지점에서 사용합니다.
- 컨베이어는 각 사이클 시작 시 이동하고 HC-SR04 감지 시 정지합니다. 배출과 고정 로봇팔 동작 후 다시 이동하며 두 번째 감지 후 최종 정지합니다.
- MyCobot은 감정/슬롯과 관계없이 하나의 고정 동작만 수행합니다.
- STT 실패 시 질문 번호를 증가시키지 않고 같은 질문으로 돌아가 재녹음합니다.
- neutral은 UI에서 '평온'으로 표시하며 Gemma가 평온/안정/차분한 답변을 적극적으로 해당 범주로 판단하도록 프롬프트를 구성했습니다. 판단 자체가 불가능한 경우에만 낮은 우선순위의 fallback으로 사용합니다.

## TEST_MODE (Space 키 테스트)
실제 ESP32 물리 버튼 없이 전체 UI/녹음/STT/Gemma 흐름을 테스트하려면 `.env`에서 `TEST_MODE=true`로 설정하세요.
- Space: 물리 버튼 1회와 동일한 이벤트
- 시작 화면에서 Space: 체험 시작
- 질문 화면: Space로 녹음 시작 → Space로 녹음 종료
- AI 응답/로봇 대기: Space로 다음 단계
- TEST_MODE에서는 하드웨어 호출이 자동으로 데모 처리됩니다.
- 실제 전시 전에는 `TEST_MODE=false`로 되돌리세요.


## V7 시작 화면 — 하드웨어 버튼 인사 흐름 (이번 수정)
- 이제 시작 화면 진입 시 자동으로 인사하지 않습니다. **ESP32 물리 버튼(GPIO13, `/api/ui/record`)을 한 번 누르면** MyCobot 인사 동작(`/api/robot/greeting`)과 함께 화면에 모노바의 인사말이 타이핑 애니메이션으로 등장합니다.
- 인사 문구: "안녕! 내 이름은 모노바야 🤖 / 나는 너의 말에 따라 감정을 분석하고 간식을 줄게! / 시작하고 싶다면 아래 빨간 큰 버튼을 눌러줘!"
- 인사가 끝나면 화면 아래 버튼이 은은한 회색 → **빨갛게 펄스(pulse)치는 큰 버튼**으로 바뀝니다. 이 버튼을 클릭하면 질문 1로 이동합니다.
- 물리 버튼을 (같은 화면에서) **한 번 더** 누르면 화면 버튼을 클릭한 것과 동일하게 질문 1로 이동합니다. 즉, 전시 중에는 하드웨어 버튼만으로도 "인사 → 시작"이 모두 가능하고, 터치스크린은 보조 수단입니다.
- 체험이 끝나고 "처음으로"를 누르면 인사 상태가 초기화되어, 다음 체험자도 다시 버튼을 눌러 인사를 들어야 합니다.
- TEST_MODE에서는 하드웨어 버튼 대신 **Space 키**가 동일하게 동작합니다 (1회째 인사, 2회째 시작).
- 관련 코드: `static/screen.js`의 `handleStartScreenButton / showRobotGreeting / pollRemoteButton`, `static/style.css`의 `.robot-bubble / #startButton.ready`.

## MyCobot 280 Wi-Fi 연결 방법
MyCobot 280 자체는 시리얼(UART/USB)로 명령을 받는 로봇팔이며, "Wi-Fi로 연결"한다는 것은 로봇팔에 꽂혀 있는 컨트롤러(M5Stack Basic/베이직, 또는 MyCobot 280 Pi에 내장된 라즈베리파이)를 네트워크에 연결해 원격에서 시리얼 대신 소켓(TCP)으로 명령을 보내는 것을 의미합니다. 이 프로젝트는 두 가지 모드를 모두 지원하도록 `hardware/robot_arm.py`를 수정했습니다.

1. **M5 컨트롤러에 Wi-Fi 연결하기**
   - mycobot 280의 M5Stack Basic(또는 M5Stack Basic이 아닌 경우 UIFlow가 올라간 컨트롤러)에서 UIFlow 앱 또는 M5의 설정 메뉴로 들어가 공유기 SSID/비밀번호를 입력해 STA 모드로 연결합니다.
   - 연결되면 M5 화면(또는 시리얼 로그)에 로컬 IP가 표시됩니다. 이 IP를 적어 둡니다.
   - `pymycobot`이 사용하는 기본 소켓 포트는 **9000**번이며, M5 쪽에서 별도 설정을 바꾸지 않았다면 그대로 사용하면 됩니다.
2. **파이썬에서 Wi-Fi(소켓)로 접속하기** — 시리얼 대신 아래처럼 접속합니다.
   ```python
   from pymycobot import MyCobot280Socket
   mc = MyCobot280Socket("<M5의 IP>", 9000)  # 예: MyCobot280Socket("10.31.202.227", 9000)
   print(mc.get_angles())          # 연결 확인
   mc.send_angles([0, 10, 0, 20, 0, 100], 20)
   ```
   (이 예시는 `hardware/mx.py`에 이미 포함되어 있습니다.)
3. **이 프로젝트에서 켜는 법** — `hardware/robot_arm.py`를 실행하는 셸(또는 systemd 서비스 파일)에 환경변수만 설정하면 코드 수정 없이 시리얼/Wi-Fi를 전환할 수 있습니다.
   ```
   MYCOBOT_MODE=wifi
   MYCOBOT_WIFI_IP=10.31.202.227
   MYCOBOT_WIFI_PORT=9000
   ```
   `MYCOBOT_MODE`를 지정하지 않거나 `serial`로 두면 기존과 동일하게 `/dev/ttyAMA0` 시리얼로 연결합니다(MyCobot 280 Pi처럼 라즈베리파이가 로봇 안에 내장되어 UART로 붙어 있는 경우).
4. **주의**
   - Wi-Fi(소켓) 모드는 M5 컨트롤러와 `robot_arm.py`를 실행하는 PC/Pi가 **같은 네트워크(같은 공유기)** 에 있어야 합니다.
   - Wi-Fi는 시리얼보다 지연(latency)이 더 크고, 공유기 혼잡 시 명령이 끊길 수 있습니다. 전시장에서는 가능하면 유선(시리얼, 또는 MyCobot 280 Pi 내장 UART)을 우선 사용하고, Wi-Fi는 케이블을 물리적으로 연결하기 어려운 자리 배치일 때만 사용하는 것을 권장합니다.
   - `robot_arm.py`(로봇 쪽 Flask, 포트 5001)와 메인 Flask 서버(`app.py`, 포트 5000)는 별개의 네트워크 연결입니다. `ROBOT_PI_URL`(메인 서버 `.env`)은 `robot_arm.py`가 돌아가는 기기의 IP:5001이어야 하며, `MYCOBOT_WIFI_IP`는 그 안에서 다시 mycobot의 M5 컨트롤러로 접속하기 위한 IP입니다. 이 둘을 헷갈리지 않도록 주의하세요.

## V6 하드웨어 센서 흐름 — 디스펜서 1회 작동
- HC-SR04 #1은 **약 1m 이내에 사탕/트레이가 존재하는지** 확인하는 센서입니다. 이 센서는 자체적으로 컨베이어를 정지시키지 않습니다.
- 컨베이어는 회로 사이클 시작과 동시에 이동합니다.
- HC-SR04 #1이 사탕/트레이를 감지한 뒤, HC-SR04 #2가 **10cm 이하**로 가까워지는 순간 컨베이어를 정지합니다.
- 정지한 위치에서 디스펜서는 **한 번만** 작동합니다. Q2/Q4는 선택된 두 회로를 하나의 `/dispense_pair` 요청으로 거의 동시에 한 번씩 작동시키며, Q5는 선택된 한 회로만 한 번 작동시킵니다.
- 디스펜서 작동 후 MyCobot은 감정/슬롯과 무관하게 **고정 동작을 한 번만** 수행합니다.
- 로봇팔 동작이 끝나면 컨베이어를 다시 이동시킵니다.
- 이후 HC-SR04 #1의 1m 감지 영역에서 사탕/트레이가 **사라지는 것**을 확인하면 컨베이어를 정지하고 해당 회로 사이클을 완료합니다.
- 따라서 한 회로 사이클에서 디스펜서가 두 번째 초음파 정지 지점에서 다시 작동하는 구조가 아닙니다.
- HC-SR04 #2는 `STOP_DISTANCE_CM = 10.0`, 다음 감지를 위한 해제 거리는 `RELEASE_DISTANCE_CM = 15.0`입니다.
- HC-SR04 #1의 존재 판단은 `PRESENCE_DISTANCE_CM = 100.0`입니다.
- 실제 장착 위치와 사탕/트레이 크기에 맞춰 이 세 값을 현장에서 보정해야 합니다.
